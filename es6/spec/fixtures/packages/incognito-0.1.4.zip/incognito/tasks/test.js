import gulp from "gulp";

gulp.task("test", ["test-local", "test-browsers"]);
